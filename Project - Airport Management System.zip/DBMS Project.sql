--create database AIRPORTMANAGEMENTSYSTEM

--USE AIRPORTMANAGEMENTSYSTEM
--unique and auto increment in primary key
/*CREATE SEQUENCE airline_id_seq START WITH 1 INCREMENT BY 1;
CREATE SEQUENCE airplane_id_seq START WITH 1 INCREMENT BY 1;
CREATE SEQUENCE flight_id_seq START WITH 1 INCREMENT BY 1;
CREATE SEQUENCE passenger_id_seq START WITH 1 INCREMENT BY 1;
CREATE SEQUENCE booking_id_seq START WITH 1 INCREMENT BY 1;
CREATE SEQUENCE staff_id_seq START WITH 1 INCREMENT BY 1;
Go 

CREATE TABLE Airline (
  AirlineID INT PRIMARY KEY ,
  AirlineName VARCHAR(255) NOT NULL
);
GO

CREATE TABLE Airplane (
  AirplaneID INT PRIMARY KEY ,
  ModelNumber VARCHAR(255) NOT NULL,
  RegistrationNumber VARCHAR(255) UNIQUE NOT NULL,
  PassengerCapacity INT NOT NULL,
  AirlineID INT NOT NULL,
  FOREIGN KEY (AirlineID) REFERENCES Airline(AirlineID)
);
GO

CREATE TABLE Flight (
  FlightID INT PRIMARY KEY ,
  FlightNumber VARCHAR(255) UNIQUE NOT NULL,
  DepartureAirport VARCHAR(255) NOT NULL,
  DestinationAirport VARCHAR(255) NOT NULL,
  DepartureDateTime DATETIME NOT NULL,
  ArrivalDateTime DATETIME NOT NULL,
  AirplaneID INT NOT NULL,
  FOREIGN KEY (AirplaneID) REFERENCES Airplane(AirplaneID)
);
GO

CREATE TABLE Passenger (
  PassengerID INT PRIMARY KEY ,
  FirstName VARCHAR(255) NOT NULL,
  LastName VARCHAR(255) NOT NULL,
  Email VARCHAR(255) UNIQUE NOT NULL
);
GO

CREATE TABLE Booking (
  BookingID INT PRIMARY KEY ,
  PassengerID INT NOT NULL,
  FlightID INT NOT NULL,
  BookingDate DATE NOT NULL,
  FOREIGN KEY (PassengerID) REFERENCES Passenger(PassengerID),
  FOREIGN KEY (FlightID) REFERENCES Flight(FlightID)
);
GO
CREATE TABLE Staff (  -- Optional table for staff details
  StaffID INT PRIMARY KEY ,
  StaffName VARCHAR(255) NOT NULL,
  Role VARCHAR(255),
);
Go
-- add airline
INSERT INTO Airline (AirlineID, AirlineName)
VALUES (NEXT VALUE FOR airline_id_seq, 'Pakistan International Airlines'),
       (NEXT VALUE FOR airline_id_seq, 'Emirates'),
       (NEXT VALUE FOR airline_id_seq, 'Qatar Airways'),
       (NEXT VALUE FOR airline_id_seq, 'Etihad Airways'),
       (NEXT VALUE FOR airline_id_seq, 'Lufthansa'),
       (NEXT VALUE FOR airline_id_seq, 'Singapore Airlines'),
       (NEXT VALUE FOR airline_id_seq, 'Turkish Airlines'),
       (NEXT VALUE FOR airline_id_seq, 'British Airways'),
       (NEXT VALUE FOR airline_id_seq, 'American Airlines'),
       (NEXT VALUE FOR airline_id_seq, 'Delta Air Lines'),
       (NEXT VALUE FOR airline_id_seq, 'United Airlines'),
       (NEXT VALUE FOR airline_id_seq, 'Air France'),
       (NEXT VALUE FOR airline_id_seq, 'KLM Royal Dutch Airlines'),
       (NEXT VALUE FOR airline_id_seq, 'China Eastern Airlines'),
       (NEXT VALUE FOR airline_id_seq, 'Japan Airlines'),
       (NEXT VALUE FOR airline_id_seq, 'Korean Air'),
       (NEXT VALUE FOR airline_id_seq, 'All Nippon Airways'),
       (NEXT VALUE FOR airline_id_seq, 'Cathay Pacific'),
       (NEXT VALUE FOR airline_id_seq, 'Qantas'),
       (NEXT VALUE FOR airline_id_seq, 'Air Canada');
GO
-- add airplane
INSERT INTO Airplane (AirplaneID, ModelNumber, RegistrationNumber, PassengerCapacity, AirlineID)
VALUES (NEXT VALUE FOR airplane_id_seq, 'Boeing 737', 'N737PIA', 200, 1),
       (NEXT VALUE FOR airplane_id_seq, 'Airbus A380', 'A380EM', 500, 2),
       (NEXT VALUE FOR airplane_id_seq, 'Boeing 777', 'B777QA', 300, 3),
       (NEXT VALUE FOR airplane_id_seq, 'Boeing 787', 'B787EA', 240, 4),
       (NEXT VALUE FOR airplane_id_seq, 'Airbus A350', 'A350LH', 350, 5),
       (NEXT VALUE FOR airplane_id_seq, 'Boeing 777', 'B777SQ', 300, 6),
       (NEXT VALUE FOR airplane_id_seq, 'Airbus A330', 'A330TK', 250, 7),
       (NEXT VALUE FOR airplane_id_seq, 'Boeing 787', 'B787BA', 240, 8),
       (NEXT VALUE FOR airplane_id_seq, 'Boeing 737', 'N737AA', 200, 9),
       (NEXT VALUE FOR airplane_id_seq, 'Boeing 757', 'N757DL', 220, 10),
       (NEXT VALUE FOR airplane_id_seq, 'Boeing 767', 'N767UA', 260, 11),
       (NEXT VALUE FOR airplane_id_seq, 'Airbus A320', 'A320AF', 180, 12),
       (NEXT VALUE FOR airplane_id_seq, 'Boeing 747', 'B747KL', 400, 13),
       (NEXT VALUE FOR airplane_id_seq, 'Airbus A350', 'A350CE', 350, 14),
       (NEXT VALUE FOR airplane_id_seq, 'Boeing 787', 'B787JL', 240, 15),
       (NEXT VALUE FOR airplane_id_seq, 'Airbus A380', 'A380KE', 500, 16),
       (NEXT VALUE FOR airplane_id_seq, 'Boeing 767', 'B767ANA', 260, 17),
       (NEXT VALUE FOR airplane_id_seq, 'Airbus A330', 'A330CX', 250, 18),
       (NEXT VALUE FOR airplane_id_seq, 'Boeing 737', 'N737QF', 200, 19),
       (NEXT VALUE FOR airplane_id_seq, 'Boeing 777', 'B777AC', 300, 20);
GO
-- add flight
INSERT INTO Flight (FlightID, FlightNumber, DepartureAirport, DestinationAirport, DepartureDateTime, ArrivalDateTime, AirplaneID)
VALUES (NEXT VALUE FOR flight_id_seq, 'PK3001', 'KHI', 'LHE', '2024-06-01 08:00:00', '2024-06-01 09:30:00', 1),
       (NEXT VALUE FOR flight_id_seq, 'EK1001', 'DXB', 'JFK', '2024-06-01 02:00:00', '2024-06-01 10:00:00', 2),
       (NEXT VALUE FOR flight_id_seq, 'QR2001', 'DOH', 'LAX', '2024-06-01 05:00:00', '2024-06-01 14:00:00', 3),
       (NEXT VALUE FOR flight_id_seq, 'EY3001', 'AUH', 'SYD', '2024-06-01 07:00:00', '2024-06-01 20:00:00', 4),
       (NEXT VALUE FOR flight_id_seq, 'LH4001', 'FRA', 'ORD', '2024-06-01 09:00:00', '2024-06-01 13:00:00', 5),
       (NEXT VALUE FOR flight_id_seq, 'SQ5001', 'SIN', 'LHR', '2024-06-01 11:00:00', '2024-06-01 20:00:00', 6),
       (NEXT VALUE FOR flight_id_seq, 'TK6001', 'IST', 'JFK', '2024-06-01 13:00:00', '2024-06-01 17:00:00', 7),
       (NEXT VALUE FOR flight_id_seq, 'BA7001', 'LHR', 'HKG', '2024-06-01 15:00:00', '2024-06-02 08:00:00', 8),
       (NEXT VALUE FOR flight_id_seq, 'AA8001', 'DFW', 'MIA', '2024-06-01 07:00:00', '2024-06-01 11:00:00', 9),
       (NEXT VALUE FOR flight_id_seq, 'DL9001', 'ATL', 'LAX', '2024-06-01 05:00:00', '2024-06-01 10:00:00', 10),
       (NEXT VALUE FOR flight_id_seq, 'UA10001', 'ORD', 'SFO', '2024-06-01 03:00:00', '2024-06-01 08:00:00', 11),
       (NEXT VALUE FOR flight_id_seq, 'AF11001', 'CDG', 'JFK', '2024-06-01 04:00:00', '2024-06-01 11:00:00', 12),
       (NEXT VALUE FOR flight_id_seq, 'KL12001', 'AMS', 'NRT', '2024-06-01 06:00:00', '2024-06-01 20:00:00', 13),
       (NEXT VALUE FOR flight_id_seq, 'MU13001', 'PVG', 'SYD', '2024-06-01 08:00:00', '2024-06-01 20:00:00', 14),
       (NEXT VALUE FOR flight_id_seq, 'JL14001', 'NRT', 'LAX', '2024-06-01 10:00:00', '2024-06-01 22:00:00', 15),
       (NEXT VALUE FOR flight_id_seq, 'KE15001', 'ICN', 'LHR', '2024-06-01 12:00:00', '2024-06-01 20:00:00', 16),
       (NEXT VALUE FOR flight_id_seq, 'NH16001', 'HND', 'SFO', '2024-06-01 14:00:00', '2024-06-01 22:00:00', 17),
       (NEXT VALUE FOR flight_id_seq, 'CX17001', 'HKG', 'YVR', '2024-06-01 16:00:00', '2024-06-01 20:00:00', 18),
       (NEXT VALUE FOR flight_id_seq, 'QF18001', 'SYD', 'DFW', '2024-06-01 18:00:00', '2024-06-01 23:00:00', 19),
       (NEXT VALUE FOR flight_id_seq, 'AC19001', 'YYZ', 'LAX', '2024-06-01 20:00:00', '2024-06-01 23:00:00', 20);
GO
-- add flight
INSERT INTO Passenger (PassengerID, FirstName, LastName, Email)
VALUES (NEXT VALUE FOR passenger_id_seq, 'John', 'Doe', 'john.doe@example.com'),
       (NEXT VALUE FOR passenger_id_seq, 'Jane', 'Smith', 'jane.smith@example.com'),
       (NEXT VALUE FOR passenger_id_seq, 'Alice', 'Johnson', 'alice.johnson@example.com'),
       (NEXT VALUE FOR passenger_id_seq, 'Bob', 'Williams', 'bob.williams@example.com'),
       (NEXT VALUE FOR passenger_id_seq, 'Charlie', 'Brown', 'charlie.brown@example.com'),
       (NEXT VALUE FOR passenger_id_seq, 'Diana', 'Jones', 'diana.jones@example.com'),
       (NEXT VALUE FOR passenger_id_seq, 'Eve', 'Davis', 'eve.davis@example.com'),
       (NEXT VALUE FOR passenger_id_seq, 'Frank', 'Miller', 'frank.miller@example.com'),
       (NEXT VALUE FOR passenger_id_seq, 'Grace', 'Wilson', 'grace.wilson@example.com'),
       (NEXT VALUE FOR passenger_id_seq, 'Henry', 'Moore', 'henry.moore@example.com'),
       (NEXT VALUE FOR passenger_id_seq, 'Ivy', 'Taylor', 'ivy.taylor@example.com'),
       (NEXT VALUE FOR passenger_id_seq, 'Jack', 'Anderson', 'jack.anderson@example.com'),
       (NEXT VALUE FOR passenger_id_seq, 'Karen', 'Thomas', 'karen.thomas@example.com'),
       (NEXT VALUE FOR passenger_id_seq, 'Leo', 'Jackson', 'leo.jackson@example.com'),
       (NEXT VALUE FOR passenger_id_seq, 'Mia', 'White', 'mia.white@example.com'),
       (NEXT VALUE FOR passenger_id_seq, 'Nick', 'Harris', 'nick.harris@example.com'),
       (NEXT VALUE FOR passenger_id_seq, 'Olivia', 'Martin', 'olivia.martin@example.com'),
       (NEXT VALUE FOR passenger_id_seq, 'Paul', 'Garcia', 'paul.garcia@example.com'),
       (NEXT VALUE FOR passenger_id_seq, 'Quinn', 'Martinez', 'quinn.martinez@example.com'),
       (NEXT VALUE FOR passenger_id_seq, 'Rachel', 'Robinson', 'rachel.robinson@example.com');
GO
-- add booking
INSERT INTO Booking (BookingID, PassengerID, FlightID, BookingDate)
VALUES (NEXT VALUE FOR booking_id_seq, 1, 1, '2024-05-01'),
       (NEXT VALUE FOR booking_id_seq, 2, 2, '2024-05-02'),
       (NEXT VALUE FOR booking_id_seq, 3, 3, '2024-05-03'),
       (NEXT VALUE FOR booking_id_seq, 4, 4, '2024-05-04'),
       (NEXT VALUE FOR booking_id_seq, 5, 5, '2024-05-05'),
       (NEXT VALUE FOR booking_id_seq, 6, 6, '2024-05-06'),
       (NEXT VALUE FOR booking_id_seq, 7, 7, '2024-05-07'),
       (NEXT VALUE FOR booking_id_seq, 8, 8, '2024-05-08'),
       (NEXT VALUE FOR booking_id_seq, 9, 9, '2024-05-09'),
       (NEXT VALUE FOR booking_id_seq, 10, 10, '2024-05-10'),
       (NEXT VALUE FOR booking_id_seq, 11, 11, '2024-05-11'),
       (NEXT VALUE FOR booking_id_seq, 12, 12, '2024-05-12'),
       (NEXT VALUE FOR booking_id_seq, 13, 13, '2024-05-13'),
       (NEXT VALUE FOR booking_id_seq, 14, 14, '2024-05-14'),
       (NEXT VALUE FOR booking_id_seq, 15, 15, '2024-05-15'),
       (NEXT VALUE FOR booking_id_seq, 16, 16, '2024-05-16'),
       (NEXT VALUE FOR booking_id_seq, 17, 17, '2024-05-17'),
       (NEXT VALUE FOR booking_id_seq, 18, 18, '2024-05-18'),
       (NEXT VALUE FOR booking_id_seq, 19, 19, '2024-05-19'),
       (NEXT VALUE FOR booking_id_seq, 20, 20, '2024-05-20');
GO
-- add staff
INSERT INTO Staff (StaffID, StaffName, Role)
VALUES (NEXT VALUE FOR staff_id_seq, 'Alice Johnson', 'Pilot'),
       (NEXT VALUE FOR staff_id_seq, 'Bob Williams', 'Co-Pilot'),
       (NEXT VALUE FOR staff_id_seq, 'Charlie Brown', 'Flight Attendant'),
       (NEXT VALUE FOR staff_id_seq, 'Diana Jones', 'Flight Attendant'),
       (NEXT VALUE FOR staff_id_seq, 'Eve Davis', 'Ground Staff'),
       (NEXT VALUE FOR staff_id_seq, 'Frank Miller', 'Maintenance'),
       (NEXT VALUE FOR staff_id_seq, 'Grace Wilson', 'Pilot'),
       (NEXT VALUE FOR staff_id_seq, 'Henry Moore', 'Co-Pilot'),
       (NEXT VALUE FOR staff_id_seq, 'Ivy Taylor', 'Flight Attendant'),
       (NEXT VALUE FOR staff_id_seq, 'Jack Anderson', 'Flight Attendant'),
       (NEXT VALUE FOR staff_id_seq, 'Karen Thomas', 'Ground Staff'),
       (NEXT VALUE FOR staff_id_seq, 'Leo Jackson', 'Maintenance'),
       (NEXT VALUE FOR staff_id_seq, 'Mia White', 'Pilot'),
       (NEXT VALUE FOR staff_id_seq, 'Nick Harris', 'Co-Pilot'),
       (NEXT VALUE FOR staff_id_seq, 'Olivia Martin', 'Flight Attendant'),
       (NEXT VALUE FOR staff_id_seq, 'Paul Garcia', 'Flight Attendant'),
       (NEXT VALUE FOR staff_id_seq, 'Quinn Martinez', 'Ground Staff'),
       (NEXT VALUE FOR staff_id_seq, 'Rachel Robinson', 'Maintenance'),
       (NEXT VALUE FOR staff_id_seq, 'Sam Carter', 'Pilot'),
       (NEXT VALUE FOR staff_id_seq, 'Tina Clark', 'Co-Pilot');
GO*/
-- list staff
--select * from Staff;

-- list booking
--select * from Booking;

-- list passengers
--select * from Passenger;

--list flight
--select * from Flight;

-- list airplane
--select * from Airplane;

-- list airline
--select * from Airline*/

/*GO

-- create view 
CREATE VIEW FlightDetail AS
SELECT�
��f.FlightID,
��f.FlightNumber,
��f.DepartureAirport,
��f.DestinationAirport,
��f.DepartureDateTime,
��f.ArrivalDateTime,
��a.ModelNumber AS AirplaneModel,
��al.AirlineName
FROM�
��Flight f
JOIN�
��Airplane a ON f.AirplaneID = a.AirplaneID
JOIN�
��Airline al ON a.AirlineID = al.AirlineID;*/

-- after create view list create view
--SELECT * FROM FlightDetail;

--update Flight
--set DepartureAirport = 'Dubai',DestinationAirport = 'Pakistan'
--where FlightID = 1;
--SELECT * FROM FlightDetail;

--
/*UPDATE Airline
SET AirlineName = 'New Airline Name'
WHERE AirlineID = 1; -- Specify the AirlineID of the airline you want to update

-- Delete a passenger from the Passenger table
DELETE FROM Passenger
WHERE PassengerID = 1; -- Specify the PassengerID of the passenger you want to delete

-- retrive booking for a date
SELECT * FROM Booking
WHERE BookingDate = '2024-05-01';*/


